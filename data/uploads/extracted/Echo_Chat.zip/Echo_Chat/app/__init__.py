# Makes app a package
from .chat_bot import ChatBot
