# Entry point for Echo_Chat addon

from chat_bot import ChatBot
import model_registry
from llm import get_llm

# Ensure model is loaded once
if model_registry.llm_instance is None:
    print("[Echo_Chat] Loading model...")
    model_registry.llm_instance = get_llm()
else:
    print("[Echo_Chat] Using already loaded model.")

# Create a global bot instance
bot = ChatBot()

def init_app(app=None):
    """
    Called by the host app when loading the addon.
    """
    print("[Echo_Chat] Addon loaded successfully.")
