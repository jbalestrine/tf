# Holds the shared LLM instance
llm_instance = None
