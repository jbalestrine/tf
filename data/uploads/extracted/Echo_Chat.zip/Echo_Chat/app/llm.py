import os
from llama_cpp import Llama

MODEL_PATH = r"C:\Users\Echo\masterchief\models\mistral-7b-instruct-v0.1.Q4_K_M.gguf"

def get_llm():
    """Load the Mistral GGUF model."""
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")

    return Llama(
        model_path=MODEL_PATH,
        n_ctx=4096,
        n_threads=8,
        n_gpu_layers=50
    )
